async function addPersistenceAttribute(user, context, callback) {
   let rp = require('request-promise@1.0.2');
   let moment = require('moment@2.11.2');
   try {
      let memberson_url = 'https://ngssgproxyuat.memgate.com';
      let svc_auth1 = 'RkxFWA==,V1k1TW9ncjl2OGlHc3ROeQ==';
      let svc_auth2 = 'RkxFWC1UWA==,RkJOZW00bllKR3lUdW9RaQ==';

      const accenture_auth_url = 'http://sng-test.elasticbeanstalk.com/api/ngstoken';
      const accenture_auth_username = 'flexsolver';
      const accenture_auth_password = 'flexsolver';
      const accenture_auth_grant_type = 'password';
      const accenture_auth_scope = 'am_application_scope user_web artwork_web comment_web';

      const accenture_signup_url = 'https://hzmmhfacy4.execute-api.ap-southeast-1.amazonaws.com/dev/user/auth0';

      let namespace = 'http://ngs.flex-solver.app/claim/';
      console.log(`clientID:`, context.clientID);
      let customer_number = user.user_metadata ? user.user_metadata.customer_number : null;
      let profile_token = null;
      let profile_token_expiry = null;
      let member_no = null;
      let accenture_user_id = user.user_metadata ? user.user_metadata.accenture_user_id : '';
      // if (context.clientID === "2aBzM98FTxT7UKk9PMm1C5F9qxC12tbR") {
      console.log(`metadata:`, user.user_metadata);
      console.log(`User:`, user);
      let auth_options = {
         method: 'POST',
         uri: memberson_url + '/api/user/login',
         headers: { SvcAuth: svc_auth1 },
         body: {
            "username": "FLEX",
            "password": "m5JFZa3nMsbL"
         },
         json: true
      };
      let result = await rp(auth_options);
      console.log('Token:', result.Token);
      let auth_token = result.Token;
      if (!auth_token) {
         throw new Error('Auth Token not found.');
      }

      if (customer_number) {
         let social_signin_options = {
            method: 'POST',
            uri: memberson_url + '/api/profile/social-signin',
            headers: { SvcAuth: svc_auth1, Token: auth_token },
            body: {
               "MediaCode": "FLEXSOLVER",
               "Identifier": customer_number
            },
            json: true
         };
         try {
            let profile_info = await rp(social_signin_options);
            console.log('Profile info:', profile_info);
            profile_token = profile_info.Token;
            profile_token_expiry = moment(profile_info.ExpiryDate).format('YYYY-MM-DD HH:mm:ss');
         } catch (error) {
            console.error('Missing profile info.');
         }
      } else {
         let is_social_user = user.identities[0] ? user.identities[0].isSocial : false;
         if (is_social_user) {
            let first_name = user.given_name;
            let last_name = user.family_name;
            let auth_options = {
               method: 'POST',
               uri: memberson_url + '/api/user/login',
               headers: { SvcAuth: svc_auth1 },
               body: {
                  "username": "FLEX",
                  "password": "m5JFZa3nMsbL"
               },
               json: true
            };
            let result = await rp(auth_options);
            console.log('Token:', result.Token);
            let auth_token = result.Token;
            if (!auth_token) {
               throw new Error('Auth Token not found.');
            }

            // Search Member
            // let search_member_options = {
            //   method: 'POST',
            //   uri: memberson_url + '/api/profile/full-search',
            //   headers: { SvcAuth: svc_auth2, Token: auth_token },
            //   body: {
            //     "EmailAddress": user.email
            //   },
            //   json: true
            // }

            // let existing_member = await rp(search_member_options);
            // if (existing_member.length === 0) {
            // create new member here
            console.log('New member, please create member info');
            let create_membership_options = {
               method: 'POST',
               uri: memberson_url + '/api/profile/create-with-membership',
               headers: { SvcAuth: svc_auth1, Token: auth_token },
               body: {
                  Profile: {
                     FirstName: first_name,
                     LastName: last_name,
                     Email: user.email,
                     JoinLocation: "LWEB",
                     Addresses: [{ "AddressType": "HOME" }]
                  },
                  Membership: {
                     MemberType: "Gallery Explorer",
                     LocationCode: "LWEB",
                     Registrator: "WEB"
                  }
               },
               json: true
            };
            console.log(create_membership_options);
            let member_info = await rp(create_membership_options);
            customer_number = member_info.Profile.CustomerNumber;
            profile_token = member_info.Profile.Token;
            profile_token_expiry = moment(member_info.Profile.TokenExpiryDate).format('YYYY-MM-DD HH:mm:ss');
            let create_social_profile_options = {
               method: 'POST',
               uri: memberson_url + `/api/profile/${customer_number}/social-profile`,
               headers: { SvcAuth: svc_auth1, Token: auth_token, ProfileToken: profile_token },
               body: {
                  "MediaCode": "FLEXSOLVER",
                  "Identifier": customer_number,
                  "ProfileDetails": {
                     "FirstName": first_name,
                     "LastName": last_name,
                     "DOB": null,
                     "Email": user.email,
                     "GenderCode": null,
                     "AcquireDateTime": moment(),
                     "ExtraProperties": null
                  }
               },
               json: true
            };
            await rp(create_social_profile_options);
            console.log('Before User metadata:', user.user_metadata);
            if (!user.user_metadata) {
               user.user_metadata = {};
            }
            user.user_metadata.customer_number = customer_number;
            user.user_metadata.first_name = first_name;
            user.user_metadata.last_name = last_name;
            user.user_metadata.terms_and_conditions = true;
            console.log('User metadata:', user.user_metadata);
            console.log('Created social user into member');
            auth0.users.updateUserMetadata(user.user_id, user.user_metadata);
         } else {
            callback(new Error('Customer Number not found!'), user, context);
         }
      }

      try {
         let auth_options = {
            method: 'POST',
            uri: memberson_url + '/api/user/login',
            headers: { SvcAuth: svc_auth2 },
            body: {
               "username": "FLEX-TX",
               "password": "QgLqPdy23YCK"
            },
            json: true
         };
         let result = await rp(auth_options);
         let retrieve_membership_token = result.Token;
         if (!auth_token) {
            throw new Error('Membership: Auth Token not found.');
         }

         let retrieve_membership_options = {
            method: 'GET',
            uri: memberson_url + `/api/profile/${customer_number}/memberships`,
            headers: { SvcAuth: svc_auth2, Token: retrieve_membership_token },
            json: true
         };
         let membership_info = await rp(retrieve_membership_options);
         if (!membership_info.length) {
            throw new Error('Membership information not found.');
         }
         for (let membership of membership_info) {
            let status = membership.Status;
            if (status !== 'ACTIVE') {
               continue;
            }
            member_no = membership.MemberNo;
            break;
         }
      } catch (error) {
         console.error(error);
      }

      try {
         if (accenture_user_id === undefined) { // Missing attribute for special reason
            console.log(`Accenture User ID of undefined, proceed to create Accenture User ID`);
            let accenture_auth_options = {
               method: 'POST',
               uri: accenture_auth_url + `?username=${accenture_auth_username}&password=${accenture_auth_password}&grant_type=${accenture_auth_grant_type}&scope=${accenture_auth_scope}`,
               json: true
            };
            let accenture_auth_result = await rp(accenture_auth_options);
            if (accenture_auth_result) {
               if (accenture_auth_result.result !== 'success') {
                  throw new Error('Authentication failed!');
               }
               let accenture_access_token = accenture_auth_result.access_token;
               console.log(`Accenture Access Token: `, accenture_access_token);

               let accenture_create_user_id_options = {
                  method: 'POST',
                  uri: accenture_signup_url,
                  headers: { Authorization: `Bearer ${accenture_access_token}` },
                  body: { email: user.email },
                  json: true
               };
               let accenture_create_user_id_result = await rp(accenture_create_user_id_options);

               if (accenture_create_user_id_result) {
                  if (accenture_create_user_id_result.result !== 'success') {
                     console.error(accenture_create_user_id_result.response.message);
                  }
                  accenture_user_id = accenture_create_user_id_result.response.id || '';
                  user.user_metadata.accenture_user_id = accenture_user_id || '';
                  auth0.users.updateUserMetadata(user.user_id, user.user_metadata);

               }
            }
         }
      } catch (error) {
         console.error(error);
      }
      // Append user_metadata onto id_token  
      context.idToken[namespace + 'customernumber'] = customer_number;
      context.idToken[namespace + 'profiletoken'] = profile_token;
      context.idToken[namespace + 'profiletokenexpiry'] = profile_token_expiry;
      context.idToken[namespace + 'accentureuserid'] = accenture_user_id;
      context.idToken[namespace + 'firstname'] = user.user_metadata.first_name || '';
      context.idToken[namespace + 'lastname'] = user.user_metadata.last_name || '';
      context.idToken[namespace + 'membernumber'] = member_no || '';
      console.log(context.idToken);

      callback(null, user, context);
      //}
   } catch (error) {
      console.error(error);
      callback(new UnauthorizedError('Authentication failed - Rule'));
   }
}