var express = require('express');
var router = express.Router();

/* GET user profile. */
router.post('/test', function (req, res, next) {
   try {
      console.log('Webhook triggered.');
      let body = req.body;
      console.log(body);
      res.json(body);
   } catch (error) {
      next(error);
   }
});

module.exports = router;
